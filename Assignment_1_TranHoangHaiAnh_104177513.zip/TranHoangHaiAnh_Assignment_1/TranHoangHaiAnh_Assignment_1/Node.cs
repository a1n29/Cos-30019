﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TranHoangHaiAnh_Assignment_1
{
    // Define a public class named Node
    public class Node
    {
        // Private fields to store node properties
        private int _pathCost;  // The cost to reach this node from the initial node
        private int _pathDepth;  // The depth (level) of this node in the search tree
        private Action _action;  // The action taken to reach this node
        private State _state;    // The state associated with this node
        private Node _parentNode;  // The parent node in the search tree

        // Public properties to get and set node properties
        public int PathCost { get { return _pathCost; } set { _pathCost = value; } }
        public int PathDepth { get { return _pathDepth; } set { _pathDepth = value; } }
        public Action Action { get { return _action; } set { _action = value; } }
        public State State { get { return _state; } set { _state = value; } }
        public Node ParentNode { get { return _parentNode; } set { _parentNode = value; } }

        // Constructor for creating the initial node
        public Node(State initState)
        {
            _pathCost = 0;
            _pathDepth = 0;
            _action = null;
            _state = initState;
            _parentNode = null;
        }

        // Constructor for creating a child node based on a parent node, an action, and a grid
        public Node(Node parentNode, Grid grid, Action action)
        {
            _pathCost = parentNode.PathCost + grid.GetActionCost(action);
            _pathDepth = parentNode.PathDepth + 1;
            _action = action;
            _state = grid.GetStateResult(parentNode.State, action);
            _parentNode = parentNode;
        }
    }
}
