﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TranHoangHaiAnh_Assignment_1
{
    // Define a public class named Wall
    public class Wall
    {
        // Private fields to store the X and Y coordinates, width, and height of the wall
        private int _x;
        private int _y;
        private int _width;
        private int _height;

        // Public properties to get and set the X and Y coordinates, width, and height
        public int X
        {
            get { return _x; }
            set { _x = value; }
        }

        public int Y
        {
            get { return _y; }
            set { _y = value; }
        }

        public int Width
        {
            get { return _width; }
            set { _width = value; }
        }

        public int Height
        {
            get { return _height; }
            set { _height = value; }
        }

        // Constructor for creating a wall with specified X and Y coordinates, width, and height
        public Wall(int x, int y, int width, int height)
        {
            _x = x;
            _y = y;
            _width = width;
            _height = height;
        }

        // Method to check if a point (x, y) is within the boundaries of the wall
        public bool InWall(int x, int y)
        {
            if ((x >= _x && x < _x + _width) && (y >= _y && y < _y + _height))
            {
                return true;
            }
            return false;
        }
    }
}
