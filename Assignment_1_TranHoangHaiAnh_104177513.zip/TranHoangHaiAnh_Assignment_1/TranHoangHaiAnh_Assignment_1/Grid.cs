﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TranHoangHaiAnh_Assignment_1
{
    // Define a public class named Grid
    public class Grid
    {
        // Private fields to store grid properties
        private int _width;
        private int _height;
        private State _initState;
        private List<State> _goalStates;
        private List<Wall> _walls;
        private List<Action> _validActions;

        // Public property to get and set the initial state
        public State InitState
        {
            get { return _initState; }
            set { _initState = value; }
        }

        // Constructor for the Grid class, initializes grid properties
        public Grid(State initState, List<State> goalStates, int width, int height, List<Wall> walls)
        {
            _width = width;
            _height = height;
            _initState = initState;
            _goalStates = goalStates;
            _walls = walls;

            // Initialize a list of valid actions
            _validActions = new List<Action>()
            {
                new Action(moveDirection.Up),
                new Action(moveDirection.Left),
                new Action(moveDirection.Down),
                new Action(moveDirection.Right)
            };
        }

        // Private method to check if a state is valid (within the grid boundaries and not blocked by walls)
        private bool ValidValidate(State state)
        {
            foreach (Wall w in _walls)
            {
                if (w.InWall(state.X, state.Y))
                    return false;
            }
            if (state.X >= 0 && state.X < _width && state.Y >= 0 && state.Y < _height)
            {
                return true;
            }
            return false;
        }

        // Public method to get valid actions from the current state
        public List<Action> GetActions(State nowState)
        {
            List<Action> _actions = new List<Action>();

            foreach (Action a in _validActions)
            {
                State sequelState = nowState + a;
                if (ValidValidate(sequelState))
                {
                    _actions.Add(a);
                }
            }
            return _actions;
        }

        // Public method to check if a state is a goal state
        public bool ValidGoal(State state)
        {
            foreach (State s in _goalStates)
            {
                if (s.EqualTo(state))
                {
                    return true;
                }
            }
            return false;
        }

        // Public method to get the cost of an action
        public int GetActionCost(Action action)
        {
            return action.Cost;
        }

        // Public method to get the result state after taking an action
        public State GetStateResult(State state, Action action)
        {
            return state + action;
        }

        // Public method to calculate the heuristic value for a state
        public int Heuristic(State state)
        {
            return _goalStates.Min(g => Math.Abs(state.X - g.X) + Math.Abs(state.Y - g.Y));
        }
    }
}
