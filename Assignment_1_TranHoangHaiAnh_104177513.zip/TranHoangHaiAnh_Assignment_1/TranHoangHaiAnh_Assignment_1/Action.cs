﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TranHoangHaiAnh_Assignment_1
{
    // Define an enumeration to represent movement directions.
    public enum moveDirection { Up, Left, Down, Right }

    // Create a class named Action for representing actions with directions and associated costs.
    public class Action
    {
        private int _cost = 1;
        private moveDirection _mDirection;

        // Property to get and set the movement direction of the action.
        public moveDirection MDirection
        {
            get { return _mDirection; }
            set { _mDirection = value; }
        }

        // Property to get and set the cost associated with the action.
        public int Cost
        {
            get { return _cost; }
            set { _cost = value; }
        }

        // Constructor for creating an Action object with a specified movement direction.
        public Action(moveDirection mDirection)
        {
            _mDirection = mDirection;
        }

        // Method to convert a movement direction enum value into a descriptive string.
        public string MoveDes(moveDirection mDirection)
        {
            switch (mDirection)
            {
                case moveDirection.Up:
                    return "Up";
                case moveDirection.Left:
                    return "Left";
                case moveDirection.Down:
                    return "Down";
                case moveDirection.Right:
                    return "Right";
                default:
                    return ""; // Returns an empty string if the direction is not recognized.
            }
        }
    }
}
