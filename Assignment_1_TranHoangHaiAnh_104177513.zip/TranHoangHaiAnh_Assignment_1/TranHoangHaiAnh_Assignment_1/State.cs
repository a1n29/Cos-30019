﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TranHoangHaiAnh_Assignment_1
{
    // Define a public class named State
    public class State
    {
        // Private fields to store the X and Y coordinates of the state
        private int _x;
        private int _y;

        // Public properties to get and set the X and Y coordinates
        public int X
        {
            get { return _x; }
            set { _x = value; }
        }

        public int Y
        {
            get { return _y; }
            set { _y = value; }
        }

        // Constructor for creating a state with specified X and Y coordinates
        public State(int x, int y)
        {
            _x = x;
            _y = y;
        }

        // Method to check if a state is equal to another state (compares X and Y coordinates)
        public bool EqualTo(State goal)
        {
            if (X == goal.X && Y == goal.Y)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Overload the + operator to update the state based on a given action
        public static State operator +(State state, Action action)
        {
            switch (action.MDirection)
            {
                case moveDirection.Up:
                    return new State(state.X, state.Y - 1);
                case moveDirection.Left:
                    return new State(state.X - 1, state.Y);
                case moveDirection.Down:
                    return new State(state.X, state.Y + 1);
                case moveDirection.Right:
                    return new State(state.X + 1, state.Y);
                default:
                    return state;
            }
        }
    }
}
