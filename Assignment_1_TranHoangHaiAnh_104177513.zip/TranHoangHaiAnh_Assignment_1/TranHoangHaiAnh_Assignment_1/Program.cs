﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using TranHoangHaiAnh_Assignment_1; // Import your custom namespace.

namespace TranHoangHaiAnh_Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length != 2)
            {
                // Check if the number of command-line arguments is not equal to 2.
                Console.WriteLine("Usage: search <filename> <method>");
                return; // Exit the program if the number of arguments is incorrect.
            }

            string inputFile = args[0]; // Store the first command-line argument as the input file name.
            string method = args[1]; // Store the second command-line argument as the search method.

            Agent agent = new Agent(inputFile); // Create an instance of the Agent class, passing the input file name.

            switch (method.ToLower())
            {
                case "dfs":
                    // If the method argument is "dfs," call the Depth-First Search algorithm.
                    agent.DFS();
                    break;
                case "bfs":
                    // If the method argument is "bfs," call the Breadth-First Search algorithm.
                    agent.BFS();
                    break;
                case "gbfs":
                    // If the method argument is "gbfs," call the Greedy Best-First Search algorithm.
                    agent.GBFS();
                    break;
                case "as":
                    // If the method argument is "as," call the A* Search algorithm.
                    agent.AS();
                    break;
                case "cus1":
                    // If the method argument is "cus1," call Custom Search Algorithm 1 (CUS1).
                    agent.CUS1();
                    break;
                case "cus2":
                    // If the method argument is "cus2," call Custom Search Algorithm 2 (CUS2).
                    agent.CUS2();
                    break;
                case "visitall":
                    // If the method argument is "visitall," call SearchAllGoals.
                    agent.VISITALL();
                    break;
                default:
                    // If the method argument is not recognized, display an error message.
                    Console.WriteLine("Invalid method. Available methods: dfs, bfs, gbfs, as, cus1, cus2, visitall");
                    break;
            }
            //Here are the codes to run in the Visual Studio software.
            //Agent Perry_the_platypus = new Agent("RobotNav-test.txt");
            //Perry_the_platypus.DFS();
            //Perry_the_platypus.BFS();
            //Perry_the_platypus.GBFS();
            //Perry_the_platypus.AS();
            //Perry_the_platypus.CUS1();
            //Perry_the_platypus.CUS2();
            //Perry_the_platypus.VISITALL();
        }
    }
}