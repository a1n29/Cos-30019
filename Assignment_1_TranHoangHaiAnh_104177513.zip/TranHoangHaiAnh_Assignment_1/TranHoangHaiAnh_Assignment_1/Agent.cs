﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace TranHoangHaiAnh_Assignment_1
{
    // Create a class named Agent to perform various search algorithms in a grid-based environment.
    public class Agent
    {
        Grid _grid;
        int _gridWidth;
        int _gridHeight;
        List<State> _goalStates = new List<State>();
        List<Wall> _walls = new List<Wall>();

        // Constructor for the Agent class, which initializes the grid and other data structures.
        public Agent(string file)
        {
            try
            {
                // Read and parse data from a text file to set up the environment.
                string[] lines = File.ReadAllLines(file);
                ParseMapSize(lines[0]);
                State initState = ParseInitialState(lines[1]);
                ParseGoalStates(lines[2]);
                ParseWalls(lines.Skip(3).ToArray());
                _grid = new Grid(initState, _goalStates, _gridWidth, _gridHeight, _walls);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error !!!: {e.Message}");
            }
        }

        // Helper method to parse the size of the grid from a line of text.
        private void ParseMapSize(string line)
        {
            string[] gridSize = line.Trim('[', ']').Split(',');
            _gridHeight = int.Parse(gridSize[0]);
            _gridWidth = int.Parse(gridSize[1]);
        }

        // Helper method to parse the initial state from a line of text.
        private State ParseInitialState(string line)
        {
            string[] initStates = line.Trim('(', ')').Split(',');
            return new State(int.Parse(initStates[0]), int.Parse(initStates[1]));
        }

        // Helper method to parse the goal states from a line of text.
        private void ParseGoalStates(string line)
        {
            string[] goals = line.Replace("(", "").Replace(")", "").Split('|');
            foreach (string g in goals)
            {
                string[] goalInputs = g.Split(",");
                State goalState = new State(int.Parse(goalInputs[0]), int.Parse(goalInputs[1]));
                _goalStates.Add(goalState);
            }
        }

        // Helper method to parse walls' information from lines of text.
        private void ParseWalls(string[] lines)
        {
            foreach (string l in lines)
            {
                string[] wallInputs = l.Trim('(', ')').Split(',');
                int x = int.Parse(wallInputs[0]);
                int y = int.Parse(wallInputs[1]);
                int width = int.Parse(wallInputs[2]);
                int height = int.Parse(wallInputs[3]);
                Wall wall = new Wall(x, y, width, height);
                _walls.Add(wall);
            }
        }

        // Helper method to find and print the path from a target node to the start node.
        private void FindPath(Node targetNode)
        {
            Node thisNode = targetNode;
            Stack<Node> pathStack = new Stack<Node>();
            while (thisNode != null)
            {
                pathStack.Push(thisNode);
                thisNode = thisNode.ParentNode;
            }
            while (pathStack.Count > 0)
            {
                Node path = pathStack.Pop();
                Console.Write($"{path.Action?.MoveDes(path.Action.MDirection)} ");
            }
            Console.WriteLine();
        }

        // Depth-First Search algorithm.
        public void DFS()
        {
            // Initialize data structures for DFS.
            Stack<Node> nodeStack = new Stack<Node>(); // Create a stack to store nodes to be explored.
            Node initNode = new Node(_grid.InitState); // Create an initial node with the starting state.
            HashSet<State> visitedStates = new HashSet<State>(); // Keep track of visited states to avoid revisiting them.
            nodeStack.Push(initNode); // Add the initial node to the stack.
            visitedStates.Add(initNode.State); // Mark the initial state as visited.

            // Perform DFS.
            while (nodeStack.Count > 0) // Continue as long as there are nodes to explore.
            {
                Node thisNode = nodeStack.Pop(); // Pop the top node from the stack.
                visitedStates.Add(thisNode.State); // Mark the state of this node as visited.

                if (_grid.ValidGoal(thisNode.State)) // Check if the current state is a valid goal state.
                {
                    Console.Write($"DFS {visitedStates.Count} \n"); // Print the number of visited states.
                    FindPath(thisNode); // Call a method to find and print the path to the goal state.
                    return; // Exit the DFS algorithm after finding a solution.
                }

                List<Action> revActions = _grid.GetActions(thisNode.State); // Get a list of available actions from the current state.
                revActions.Reverse(); // Reverse the list of actions to maintain the order of exploration.

                foreach (Action a in revActions) // Iterate through available actions.
                {
                    bool exploredCheck = false; // Initialize a flag to check if the state resulting from this action has been explored before.
                    State succeedState = _grid.GetStateResult(thisNode.State, a); // Calculate the state that results from applying the action.

                    // Check if the succeeding state has been visited before.
                    foreach (State s in visitedStates)
                    {
                        if (s.EqualTo(succeedState)) // Check if the states are equal (custom comparison method).
                        {
                            exploredCheck = true; // Set the flag to true if the state has been explored.
                            break; // Exit the loop, no need to check further.
                        }
                    }

                    if (!exploredCheck) // If the state has not been explored, create a new node and push it to the stack.
                    {
                        Node childNode = new Node(thisNode, _grid, a); // Create a new node for the succeeding state.
                        nodeStack.Push(childNode); // Add the new node to the stack for further exploration.
                    }
                }
            }

            Console.WriteLine("No solution found"); // If the stack is empty and no solution is found, print a message indicating that no solution was found.
        }

        // Breadth-First Search algorithm.
        public void BFS()
        {
            // Initialize data structures for BFS.
            Node initNode = new Node(_grid.InitState); // Create the initial node with the starting state.
            Queue<Node> nodeQueue = new Queue<Node>(); // Create a queue to store nodes to be explored in a breadth-first manner.
            nodeQueue.Enqueue(initNode); // Enqueue the initial node to start the search.
            HashSet<State> visitedStates = new HashSet<State>(); // Keep track of visited states to avoid revisiting them.
            visitedStates.Add(initNode.State); // Mark the initial state as visited.

            // Perform BFS.
            while (nodeQueue.Count > 0) // Continue as long as there are nodes to explore in the queue.
            {
                Node thisNode = nodeQueue.Dequeue(); // Dequeue the front node from the queue for exploration.

                if (_grid.ValidGoal(thisNode.State)) // Check if the current state is a valid goal state.
                {
                    Console.WriteLine($"BFS {visitedStates.Count} "); // Print the number of visited states.
                    FindPath(thisNode); // Call a method to find and print the path to the goal state.
                    return; // Exit the BFS algorithm after finding a solution.
                }

                foreach (Action a in _grid.GetActions(thisNode.State)) // Iterate through available actions from the current state.
                {
                    bool exploredCheck = false; // Initialize a flag to check if the state resulting from this action has been explored before.
                    State succeedState = _grid.GetStateResult(thisNode.State, a); // Calculate the state that results from applying the action.

                    // Check if the succeeding state has been visited before.
                    foreach (State s in visitedStates)
                    {
                        if (s.EqualTo(succeedState)) // Check if the states are equal (custom comparison method).
                        {
                            exploredCheck = true; // Set the flag to true if the state has been explored.
                            break; // Exit the loop, no need to check further.
                        }
                    }

                    if (!exploredCheck) // If the state has not been explored, add it to the visited states, and enqueue a new node.
                    {
                        visitedStates.Add(succeedState); // Mark the state as visited.
                        Node childNode = new Node(thisNode, _grid, a); // Create a new node for the succeeding state.
                        nodeQueue.Enqueue(childNode); // Enqueue the new node for further exploration.
                    }
                }
            }

            Console.WriteLine("No solution found"); // If the queue is empty and no solution is found, print a message indicating that no solution was found.
        }


        // Greedy Best-First Search algorithm.
        public void GBFS()
        {
            // Initialize data structures for GBFS.
            Node initNode = new Node(_grid.InitState); // Create the initial node with the starting state.
            HashSet<State> visitedStates = new HashSet<State>(); // Keep track of visited states to avoid revisiting them.
            PriorityQueue<Node, int> priorityQueue = new PriorityQueue<Node, int>(); // Create a priority queue to store nodes based on a heuristic value.
            priorityQueue.Enqueue(initNode, _grid.Heuristic(initNode.State)); // Enqueue the initial node with its heuristic value.

            // Perform GBFS.
            while (priorityQueue.Count > 0) // Continue as long as there are nodes in the priority queue.
            {
                Node thisNode = priorityQueue.Dequeue(); // Dequeue the node with the highest heuristic value for exploration.

                if (_grid.ValidGoal(thisNode.State)) // Check if the current state is a valid goal state.
                {
                    Console.WriteLine($"GBFS {visitedStates.Count} "); // Print the number of visited states.
                    FindPath(thisNode); // Call a method to find and print the path to the goal state.
                    return; // Exit the GBFS algorithm after finding a solution.
                }

                foreach (Action a in _grid.GetActions(thisNode.State)) // Iterate through available actions from the current state.
                {
                    bool exploredCheck = false; // Initialize a flag to check if the state resulting from this action has been explored before.
                    State succeedState = _grid.GetStateResult(thisNode.State, a); // Calculate the state that results from applying the action.

                    // Check if the succeeding state has been visited before.
                    foreach (State s in visitedStates)
                    {
                        if (s.EqualTo(succeedState)) // Check if the states are equal (custom comparison method).
                        {
                            exploredCheck = true; // Set the flag to true if the state has been explored.
                            break; // Exit the loop, no need to check further.
                        }
                    }

                    if (!exploredCheck) // If the state has not been explored, add it to the visited states and enqueue a new node with its heuristic value.
                    {
                        visitedStates.Add(succeedState); // Mark the state as visited.
                        Node childNode = new Node(thisNode, _grid, a); // Create a new node for the succeeding state.
                        priorityQueue.Enqueue(childNode, _grid.Heuristic(childNode.State)); // Enqueue the new node with its heuristic value for further exploration.
                    }
                }
            }

            Console.WriteLine("No solution found"); // If the priority queue is empty and no solution is found, print a message indicating that no solution was found.
        }


        // A* Search algorithm.
        public void AS()
        {
            // Initialize data structures for A* Search.
            int queueLocation = 0; // Initialize a variable to keep track of the queue location.
            Node initNode = new Node(_grid.InitState); // Create the initial node with the starting state.
            HashSet<State> visitedStates = new HashSet<State>(); // Keep track of visited states to avoid revisiting them.

            // Use a priority queue with a tuple of (heuristic + path cost, queue location) for sorting.
            PriorityQueue<Node, (int, int)> priorityQueue = new PriorityQueue<Node, (int, int)>(new QueueCompareTool());

            // Enqueue the initial node with its priority value (heuristic + path cost) and queue location.
            priorityQueue.Enqueue(initNode, (_grid.Heuristic(initNode.State), queueLocation));
            queueLocation += 1;

            // Perform A* Search.
            while (priorityQueue.Count > 0) // Continue as long as there are nodes in the priority queue.
            {
                Node thisNode = priorityQueue.Dequeue(); // Dequeue the node with the highest priority for exploration.

                if (_grid.ValidGoal(thisNode.State)) // Check if the current state is a valid goal state.
                {
                    Console.WriteLine($"AS {visitedStates.Count} "); // Print the number of visited states.
                    FindPath(thisNode); // Call a method to find and print the path to the goal state.
                    return; // Exit the A* Search algorithm after finding a solution.
                }

                foreach (Action a in _grid.GetActions(thisNode.State)) // Iterate through available actions from the current state.
                {
                    bool exploredCheck = false; // Initialize a flag to check if the state resulting from this action has been explored before.
                    State succeedState = _grid.GetStateResult(thisNode.State, a); // Calculate the state that results from applying the action.

                    // Check if the child state has already been explored.
                    foreach (State s in visitedStates)
                    {
                        if (s.EqualTo(succeedState)) // Check if the states are equal (custom comparison method).
                        {
                            exploredCheck = true; // Set the flag to true if the state has been explored.
                            break; // Exit the loop, no need to check further.
                        }
                    }

                    if (!exploredCheck) // If the state has not been explored, proceed.
                    {
                        bool queueCheck = false; // Initialize a flag to check if the child state is already in the priority queue.
                        Node childNode = new Node(thisNode, _grid, a); // Create a new node for the succeeding state.
                        visitedStates.Add(thisNode.State); // Mark the current state as visited.

                        // Check if the child state is already in the priority queue.
                        foreach ((Node, (int, int)) n in priorityQueue.UnorderedItems)
                        {
                            if (n.Item1.State.EqualTo(childNode.State)) // Check if the states are equal (custom comparison method).
                            {
                                queueCheck = true; // Set the flag to true if the state is in the queue.
                                break; // Exit the loop, no need to check further.
                            }
                        }

                        if (!queueCheck) // If the state is not in the priority queue, enqueue it.
                        {
                            // Calculate the priority by adding the heuristic and path cost.
                            priorityQueue.Enqueue(childNode, (_grid.Heuristic(childNode.State) + childNode.PathCost, queueLocation));
                            queueLocation += 1; // Increment the queue location.
                        }
                    }
                }
            }

            Console.WriteLine("No solution found"); // If the priority queue is empty and no solution is found, print a message indicating that no solution was found.
        }

        // Uniform Cost Search (UCS)
        // Custom Search Algorithm 1 (CUS1).
        public void CUS1()
        {
            // Initialize data structures for CUS1.
            Node initNode = new Node(_grid.InitState); // Create the initial node with the starting state.
            HashSet<State> visitedStates = new HashSet<State>(); // Keep track of visited states to avoid revisiting them.
            PriorityQueue<Node, int> priorityQueue = new PriorityQueue<Node, int>(); // Create a priority queue to store nodes based on their cost.

            // Enqueue the initial node with a cost of 0.
            priorityQueue.Enqueue(initNode, 0);

            // Perform CUS1.
            while (priorityQueue.Count > 0) // Continue as long as there are nodes in the priority queue.
            {
                Node thisNode = priorityQueue.Dequeue(); // Dequeue the node with the lowest cost for exploration.

                if (_grid.ValidGoal(thisNode.State)) // Check if the current state is a valid goal state.
                {
                    Console.Write($"CUS1 {visitedStates.Count} \n"); // Print the number of visited states.
                    FindPath(thisNode); // Call a method to find and print the path to the goal state.
                    return; // Exit the CUS1 algorithm after finding a solution.
                }

                foreach (Action a in _grid.GetActions(thisNode.State)) // Iterate through available actions from the current state.
                {
                    bool exploredCheck = false; // Initialize a flag to check if the state resulting from this action has been explored before.
                    State succeedState = _grid.GetStateResult(thisNode.State, a); // Calculate the state that results from applying the action.

                    // Check if the child state has already been explored.
                    foreach (State s in visitedStates)
                    {
                        if (s.EqualTo(succeedState)) // Check if the states are equal (custom comparison method).
                        {
                            exploredCheck = true; // Set the flag to true if the state has been explored.
                            break; // Exit the loop, no need to check further.
                        }
                    }

                    if (!exploredCheck) // If the state has not been explored, proceed.
                    {
                        visitedStates.Add(succeedState); // Mark the succeeding state as visited.
                        Node childNode = new Node(thisNode, _grid, a); // Create a new node for the succeeding state.
                        int cost = thisNode.PathCost + _grid.GetActionCost(a); // Calculate the cost to reach the child state.
                        priorityQueue.Enqueue(childNode, cost); // Enqueue the new node with its cost for further exploration.
                    }
                }
            }

            Console.WriteLine("No solution found"); // If the priority queue is empty and no solution is found, print a message indicating that no solution was found.
        }

        // Limited-Width Beam Search
        // Custom Search Algorithm 2 (CUS2).
        public void CUS2()
        {
            // Initialize data structures for CUS2.
            int beamWidth = 3; // Set the beam width, which determines how many nodes to consider at each level change this value when the data becomes larger.
            HashSet<State> visitedStates = new HashSet<State>(); // Keep track of visited states to avoid revisiting them.
            Node initNode = new Node(_grid.InitState); // Create the initial node with the starting state.
            List<Node> currentNodes = new List<Node> { initNode }; // Start with the initial node in the current node list.

            // Perform CUS2.
            while (currentNodes.Count > 0) // Continue as long as there are nodes in the current node list.
            {
                List<Node> nextNodes = new List<Node>(); // Create a list to store nodes for the next level of exploration.
                foreach (Node thisNode in currentNodes) // Iterate through the nodes in the current node list.
                {
                    if (_grid.ValidGoal(thisNode.State)) // Check if the current state is a valid goal state.
                    {
                        Console.WriteLine($"CUS2 {visitedStates.Count} "); // Print the number of visited states.
                        FindPath(thisNode); // Call a method to find and print the path to the goal state.
                        return; // Exit the CUS2 algorithm after finding a solution.
                    }

                    List<Node> childNodes = new List<Node>(); // Create a list to store child nodes.
                    foreach (Action a in _grid.GetActions(thisNode.State)) // Iterate through available actions from the current state.
                    {
                        bool exploredCheck = false; // Initialize a flag to check if the state resulting from this action has been explored before.
                        State succeedState = _grid.GetStateResult(thisNode.State, a); // Calculate the state that results from applying the action.

                        // Check if the child state has already been explored.
                        foreach (State s in visitedStates)
                        {
                            if (s.EqualTo(succeedState)) // Check if the states are equal (custom comparison method).
                            {
                                exploredCheck = true; // Set the flag to true if the state has been explored.
                                break; // Exit the loop, no need to check further.
                            }
                        }

                        if (!exploredCheck) // If the state has not been explored, proceed.
                        {
                            visitedStates.Add(thisNode.State); // Mark the current state as visited.
                            Node childNode = new Node(thisNode, _grid, a); // Create a new node for the succeeding state.
                            childNodes.Add(childNode); // Add the child node to the list of child nodes.
                        }
                    }

                    // Sort child nodes based on their heuristic values and take a subset of them based on the beam width.
                    childNodes.Sort((node1, node2) => _grid.Heuristic(node1.State) - _grid.Heuristic(node2.State));
                    nextNodes.AddRange(childNodes.Take(beamWidth)); // Add the selected child nodes to the next node list.
                }

                // Sort next nodes based on their heuristic values and take a subset of them based on the beam width.
                nextNodes.Sort((node1, node2) => _grid.Heuristic(node1.State) - _grid.Heuristic(node2.State));
                currentNodes = nextNodes.Take(beamWidth).ToList(); // Update the current node list with the selected nodes for the next level.
            }

            Console.WriteLine("No solution found"); // If there are no nodes left to explore and no solution is found, print a message indicating that no solution was found.
        }
        public void VISITALL()
        {
            // Initialize data structures
            HashSet<State> visitedStates = new HashSet<State>();
            HashSet<State> visitedGoals = new HashSet<State>();
            Node initNode = new Node(_grid.InitState);
            Queue<Node> nodeQueue = new Queue<Node>();

            // Enqueue the initial node and mark it as visited
            nodeQueue.Enqueue(initNode);
            visitedStates.Add(initNode.State);

            // Continue until all goal states have been visited
            while (visitedGoals.Count < _goalStates.Count)
            {
                // Process nodes in the current queue
                while (nodeQueue.Count > 0)
                {
                    Node thisNode = nodeQueue.Dequeue();

                    // Check if this node is a goal state and not visited before
                    if (!visitedGoals.Contains(thisNode.State) && _grid.ValidGoal(thisNode.State))
                    {
                        visitedGoals.Add(thisNode.State);

                        // Print the path to the goal state

                        Console.WriteLine($"VISITALL ");
                        FindPath(thisNode);

                        // Clear visitedStates and nodeQueue, and enqueue this node
                        visitedStates.Clear();
                        nodeQueue.Clear();
                        nodeQueue.Enqueue(thisNode);
                        visitedStates.Add(thisNode.State);
                        break; // Exit the loop to visit the next goal state
                    }

                    // Explore child nodes for valid actions
                    foreach (Action a in _grid.GetActions(thisNode.State))
                    {
                        bool exploredCheck = false;
                        State succeedState = _grid.GetStateResult(thisNode.State, a);

                        // Check if the state has been explored
                        foreach (State s in visitedStates)
                        {
                            if (s.EqualTo(succeedState))
                            {
                                exploredCheck = true;
                                break;
                            }
                        }

                        // If the state has not been explored, proceed
                        if (!exploredCheck)
                        {
                            visitedStates.Add(thisNode.State);
                            Node childNode = new Node(thisNode, _grid, a);
                            nodeQueue.Enqueue(childNode);
                        }
                    }
                }
            }

            // If not all goal states are visited, no solution was found
            if (visitedGoals.Count < _goalStates.Count)
            {
                Console.WriteLine("No solution found");
            }
        }

    }
}