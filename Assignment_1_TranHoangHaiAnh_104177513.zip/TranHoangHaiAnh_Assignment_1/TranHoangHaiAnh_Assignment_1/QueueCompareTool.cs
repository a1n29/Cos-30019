﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TranHoangHaiAnh_Assignment_1
{
    // Define a public class named QueueCompareTool that implements the IComparer interface
    public class QueueCompareTool : IComparer<(int, int)>
    {
        // Implement the Compare method required by the IComparer interface
        public int Compare((int, int) left, (int, int) right)
        {
            // Compare the first items (Item1) of the two tuples
            int comparer = left.Item1.CompareTo(right.Item1);

            // If the first items are not equal, return the result of the comparison
            if (comparer != 0)
                return comparer;

            // If the first items are equal, compare the second items (Item2) of the two tuples
            return left.Item2.CompareTo(right.Item2);
        }
    }
}
