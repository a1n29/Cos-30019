import re

class Phrase:
    def __init__(self, phrase):
        """
        Initializes the Phrase object with the given input phrase.

        Args:
            phrase (str): The input phrase.
        """
        self.elemental = {}
        self.tokens = []
        self.base = []

        # Extract tokens and origin from the input phrase
        tokens = re.split("=>|&|\(|\)|~|\|\||<=>", phrase)
        self.tokens = list(set(token for token in tokens if token != ""))
        
        origin = re.split("(=>|&|\(|\)|~|\|\||<=>)", phrase)
        self.origin = [token for token in origin if token != ""]

        # Analyze the origin to create the base structure
        self.base = self.analyze(self.origin)

    def add_element(self, connector, index, phrase):
        """
        Adds an element to the Phrase based on the connector and index.

        Args:
            connector (str): The logical connector.
            index (int): The index where the element needs to be added.
            phrase (list): The current state of the phrase.

        Returns:
            list: The modified phrase after adding the element.
        """
        if connector != '~':
            element = [phrase[index - 1], phrase[index], phrase[index + 1]]
        else:
            element = [phrase[index], phrase[index + 1]]

        element_cipher = "element" + str(len(self.elemental) + 1)
        self.elemental[element_cipher] = element
        phrase[index - (connector != '~'): index + 2] = [element_cipher]

        return phrase

    def analyze(self, phrase):
        """
        Analyzes the phrase and recursively builds the base structure.

        Args:
            phrase (list): The current state of the phrase.

        Returns:
            list: The modified phrase after analysis.
        """
        while '(' in phrase:
            l_count = 1
            r_count = 0
            l_index = phrase.index('(')
            r_index = 0
            
            for i in range(l_index + 1, len(phrase)):
                if phrase[i] == '(':
                    l_count += 1
                if phrase[i] == ')':
                    r_count += 1
                if l_count == r_count:
                    r_index = i
                    break
            if r_index == 0:
                raise Exception("Invalid format!!!", phrase)

            segment = phrase[l_index + 1: r_index]
            segment = self.analyze(segment)

            if len(segment) != 1:
                raise Exception("Invalid segment!!!", segment)
            else:
                phrase[l_index: r_index + 1] = segment

        while '&' in phrase or '||' in phrase:
            connector = '&' if '&' in phrase else '||'
            index = phrase.index(connector)
            phrase = self.add_element(connector, index, phrase)
        
        while '~' in phrase:
            index = phrase.index('~')
            phrase = self.add_element('~', index, phrase)

        for operator in ['<=>', '=>']:
            while operator in phrase:
                index = phrase.index(operator)
                phrase = self.add_element(operator, index, phrase)

        return phrase

    def decipher(self, mem):
        """
        Deciphers the phrase based on the given memory.

        Args:
            mem (dict): The memory containing the truth values of tokens.

        Returns:
            bool: The truth value of the base token.
        """
        state_pair = {}

        # Initialize state_pair with known truth values
        for token in self.tokens:
            if token in mem:
                state_pair[token] = mem[token]
            else:
                raise Exception("Pair error!!!")

        # Evaluate the elemental expressions in the phrase
        for cipher, elements in self.elemental.items():
            if len(elements) == 2:
                rEle = state_pair[elements[1]]
                state_pair[cipher] = not rEle
            elif len(elements) == 3:
                lEle = state_pair[elements[0]]
                rEle = state_pair[elements[2]]
                if elements[1] == '&':
                    state_pair[cipher] = lEle and rEle
                elif elements[1] == '<=>':
                    state_pair[cipher] = lEle == rEle
                elif elements[1] == '=>':
                    state_pair[cipher] = not lEle or rEle
                elif elements[1] == '||':
                    state_pair[cipher] = lEle or rEle
            else:
                raise Exception("Phrase format invalid!!!", elements)

        return state_pair[self.base[0]]

if __name__ == "__main__":
    pass
