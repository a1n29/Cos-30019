import re

class HornForm:
    def __init__(self, phrase):
        """
        Initializes the HornForm object with the given phrase.

        Args:
            phrase (str): The input phrase in Horn form.
        """
        self.source = ""
        self.clause = []
        self.tokens = []
        self.joints = []

        # Split the input phrase using regular expressions to extract tokens
        self.clause = re.split(r"(=>|&|\(|\)|~|\|\||<=>)", phrase)

        # Remove empty and unnecessary tokens
        self.clause = [token for token in self.clause if token not in {"", "(", ")"}]

        # Check if the phrase is in valid Horn form
        if any(operator in self.clause for operator in ['~', '||', '<=>']):
            raise Exception("Phrase isn't in a valid Horn form!!!", self.clause)

        # Process the tokens based on the form
        if len(self.clause) == 1:
            self.source = self.clause[0]
        else:
            index = self.clause.index('=>')
            rChar = self.clause[index + 1:]

            # Check for invalid Horn form
            if len(rChar) > 1:
                raise Exception("Invalid HornForm!!!", self.clause)

            self.source = rChar[0]
            lChar = self.clause[:index]

            # Check for invalid Horn form
            if any(lChar[i] == lChar[i + 1] for i in range(len(lChar) - 1)) or lChar[-1] == '&' or lChar[0] == '&':
                raise Exception("Invalid HornForm!!!", self.clause)

            # Process joints and tokens
            for element in lChar:
                if element != '&':
                    self.joints.append(element)
            self.tokens = self.joints.copy()

        # Add the source to tokens if not present
        if self.source not in self.tokens:
            self.tokens.append(self.source)
