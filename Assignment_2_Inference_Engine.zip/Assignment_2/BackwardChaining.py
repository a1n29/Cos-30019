class BackwardChaining:
    def __init__(self, knowledge_base):
        """
        Initializes the BackwardChaining object with the given knowledge base.

        Args:
            knowledge_base (KnowledgeBase): The knowledge base containing phrases.
        """
        self.kb = knowledge_base

    def checker(self, deleted, path, sol):
        """
        Recursive function to check if a solution can be derived using backward chaining.

        Args:
            deleted (list): List of deleted solutions to avoid redundancy.
            path (list): List representing the current path in the backward chaining process.
            sol (str): The solution being checked.

        Returns:
            tuple: A tuple containing a boolean indicating whether a solution is found and the updated path.
        """
        # Check for direct solutions with no joints
        for phrase in self.kb.phrases:
            if sol == phrase.source and len(phrase.joints) == 0:
                path.append(sol)
                return True, path

        # Mark the solution as deleted to avoid circular dependencies
        deleted.append(sol)

        # Check solutions connected through joints
        for phrase in self.kb.phrases:
            if sol == phrase.source:
                # Check if all branches lead to a solution
                is_true = all(
                    branch_sol in path or branch_sol in deleted or self.checker(deleted, path, branch_sol)[0]
                    for branch_sol in phrase.joints
                )

                if is_true:
                    path.append(sol)
                    return True, path

        return False, path

    def backward_chained(self, sol):
        """
        Perform backward chaining to find a solution.

        Args:
            sol (str): The solution to find.

        Returns:
            tuple: A tuple containing a boolean indicating whether a solution is found and the path.
        """
        deleted = []
        path = []

        # Check for direct solutions with no joints
        for phrase in self.kb.phrases:
            if len(phrase.joints) == 0 and sol == phrase.source:
                return True, [sol]

        return self.checker(deleted, path, sol)

    def decipher(self, query):
        """
        Decipher a query using backward chaining.

        Args:
            query (str): The query to decipher.

        Returns:
            str: The deciphered output.
        """
        output_found, path = self.backward_chained(query)

        if output_found:
            output = f"YES: {', '.join(path)}"
        else:
            output = "NO"

        return output
