class FileProcessor:
    @staticmethod
    def process_file(filename):
        """
        Processes a file containing 'tell' and 'ask' statements.

        Args:
            filename (str): The name of the file to be processed.

        Returns:
            tuple: A tuple containing a list of 'tell' statements and an 'ask' statement.
        """
        # Initialize variables
        answer = False
        tell = []
        ask = ''

        # Open the file and process each line
        with open(filename) as file:
            for line in file:
                # Split each line into individual statements
                statements = line.strip().split(";")

                # Process each statement
                for statement in statements:
                    # Clean and normalize the statement
                    normalized_statement = statement.lower().replace(" ", "")

                    # Check if the statement is 'ask'
                    if normalized_statement == "ask":
                        answer = True

                    # Check if the statement is neither 'tell' nor 'ask' and is not empty
                    if normalized_statement != "tell" and normalized_statement != "ask" and normalized_statement:
                        # Add the statement to 'tell' if 'ask' hasn't been encountered yet
                        if not answer:
                            tell.append(normalized_statement)
                        else:
                            # Set 'ask' if 'ask' has been encountered
                            ask = normalized_statement

        return tell, ask
