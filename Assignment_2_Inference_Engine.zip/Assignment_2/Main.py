import sys
from FileProcessor import FileProcessor
from KnowledgeBases import KnowledgeBases
from TruthTableChecking import TruthTableChecking
from ForwardChaining import ForwardChaining
from BackwardChaining import BackwardChaining

def main():
    # Check if the correct number of command-line arguments is provided
    if len(sys.argv) != 3:
        print("Enter the command in the following format: method filename")
        print("Methods: TT, FC, and BC")
        sys.exit(0)

    try:
        # Read tell and ask from the file
        tell, ask = FileProcessor.process_file(sys.argv[2])
    except FileNotFoundError:
        print("File not found.")
        sys.exit(0)

    # Check if tell and ask are not empty
    if not tell:
        print("No tell found.")
        sys.exit(0)
    if not ask:
        print("No ask found.")
        sys.exit(0)

    # Get the method from the command line arguments
    method = sys.argv[1]

    # Perform the specified method based on the command-line argument
    if method == 'TT':
        kb = KnowledgeBases(tell, 'P')
        tt = TruthTableChecking(kb)
        print(tt.decipher(ask))
    elif method == 'FC':
        kb = KnowledgeBases(tell, 'H')
        fc = ForwardChaining(kb)
        print(fc.decipher(ask))
    elif method == 'BC':
        kb = KnowledgeBases(tell, 'H')
        bc = BackwardChaining(kb)
        print(bc.decipher(ask))
    else:
        print("Unknown method entered.")

if __name__ == "__main__":
    main()
