from Phrase import Phrase
from HornForm import HornForm

class KnowledgeBases:
    def __init__(self, phrases, cat):
        """
        Initializes the KnowledgeBases object with a list of phrases and a category.

        Args:
            phrases (list): A list of phrases to be added to the knowledge base.
            cat (str): The category of phrases ('P' for general phrases, 'H' for HornForm).
        """
        self.phrases = []
        self.tokens = []

        # Check if the category is valid
        if cat in ('P', 'H'):
            self.cat = cat
        else:
            raise Exception("Invalid phrase category!!!")

        # Process each phrase and add it to the knowledge base
        for phrase in phrases:
            self.tell(phrase)

    def tell(self, phrase):
        """
        Adds a new phrase to the knowledge base.

        Args:
            phrase (str): The input phrase to be added.
        """
        # Create a new Phrase or HornForm object based on the category
        if self.cat == 'P':
            new_phrase = Phrase(phrase)
        elif self.cat == 'H':
            new_phrase = HornForm(phrase)

        # Extend the tokens with unique tokens from the new phrase
        self.tokens.extend(t for t in new_phrase.tokens if t not in self.tokens)

        # Append the new phrase to the list of phrases
        self.phrases.append(new_phrase)
