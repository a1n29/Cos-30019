class ForwardChaining:
    def __init__(self, knowledge_base):
        """
        Initializes the ForwardChaining object with the given knowledge base.

        Args:
            knowledge_base (KnowledgeBase): The knowledge base containing phrases and tokens.
        """
        self.kb = knowledge_base

    def forward_chained(self, query):
        """
        Performs forward chaining to determine if a query can be derived from the knowledge base.

        Args:
            query (str): The query to be evaluated.

        Returns:
            tuple: A tuple containing a boolean indicating whether a solution is found and the path.
        """
        path = []
        truth = []
        logical = {t: False for t in self.kb.tokens}
        counter = {phrase: len(phrase.joints) for phrase in self.kb.phrases if len(phrase.joints) > 0}

        # Check for direct solutions with no joints
        for phrase in self.kb.phrases:
            if len(phrase.joints) == 0:
                if phrase.source == query:
                    return True, [query]
                truth.append(phrase.source)

        # Process through forward chaining
        while len(truth) != 0:
            t = truth.pop(0)
            path.append(t)

            if not logical[t]:
                logical[t] = True

                for c in counter:
                    if t in c.joints:
                        counter[c] -= 1

                        if counter[c] == 0:
                            if c.source == query:
                                path.append(query)
                                return True, path
                            truth.append(c.source)

        return False, []

    def decipher(self, query):
        """
        Deciphers a query using forward chaining.

        Args:
            query (str): The query to decipher.

        Returns:
            str: The deciphered output.
        """
        output_found, path = self.forward_chained(query)

        if output_found:
            output = f"YES: {', '.join(path)}"
        else:
            output = "NO"

        return output
