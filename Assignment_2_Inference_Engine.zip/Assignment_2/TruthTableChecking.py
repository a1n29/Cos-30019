from Phrase import Phrase

class TruthTableChecking:
    def __init__(self, knowledge_base):
        """
        Initializes the TruthTableChecking object with the given knowledge base.

        Args:
            knowledge_base (KnowledgeBase): The knowledge base containing phrases and tokens.
        """
        self.counter = 0
        self.kb = knowledge_base

    def verified(self, model, initial, tokens):
        """
        Recursively checks the truth value of the given model against the knowledge base.

        Args:
            model (dict): The current truth values of tokens in the model.
            initial (Phrase): The initial phrase to be verified.
            tokens (list): The remaining tokens to be processed.

        Returns:
            bool: True if the model satisfies the knowledge base and initial phrase, otherwise False.
        """
        if tokens:
            t = tokens[0]
            r = tokens[1:]

            model_1 = model.copy()
            model_1[t] = True
            model_2 = model.copy()
            model_2[t] = False

            return self.verified(model_1, initial, r) and self.verified(model_2, initial, r)
        else:
            # Check if the model satisfies all phrases in the knowledge base
            is_true = all(phrase.decipher(model) for phrase in self.kb.phrases)

            if is_true:
                # Evaluate the initial phrase with the current model
                initial_output = initial.decipher(model)
                if initial_output:
                    self.counter += 1
                return initial_output
            else:
                return True

    def include(self, initial):
        """
        Checks if the knowledge base includes the truth value of the initial phrase.

        Args:
            initial (Phrase): The initial phrase to be checked.

        Returns:
            bool: True if the initial phrase is included in the knowledge base, otherwise False.
        """
        tokens = self.kb.tokens

        # Update tokens with additional tokens from the initial phrase
        for t in initial.tokens:
            if t not in tokens:
                tokens.append(t)

        return self.verified({}, initial, tokens)

    def decipher(self, ask):
        """
        Deciphers the ask phrase using truth table checking.

        Args:
            ask (str): The ask phrase to be deciphered.

        Returns:
            str: The deciphered output.
        """
        initial = Phrase(ask)
        output_found = self.include(initial)

        if output_found:
            output = "YES: " + str(self.counter)
        else:
            output = "NO"

        return output
